<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Snarkk Banner</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="http://malsup.github.com/jquery.cycle2.js"></script>
<link rel="stylesheet" type="text/css" href="slideshow_carousel_cycle2.css">
</head>

<body>

<div class="cycle-slideshow" "cycle-autoinit" 
    data-cycle-fx="scrollHorz"
    data-cycle-speed="20000"
    data-cycle-timeout="1"
    data-cycle-easing="linear"
    >
    <img src="images/2010s_001s.png">
    <img src="images/2010s_002s.png">
    <img src="images/2010s_003s.png">
</div>
</body>
</html>